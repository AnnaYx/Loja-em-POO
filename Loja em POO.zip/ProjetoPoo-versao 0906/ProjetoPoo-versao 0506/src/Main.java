import dao.*;
import model.*;

import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ParseException, SQLException {
        Scanner sc = new Scanner(System.in);
        int opcaoMenu = 0;
        while (opcaoMenu != 9) {
            System.out.println("⊹₊｡ꕤ˚₊⊹ MENU ⊹₊｡ꕤ˚₊⊹");
            System.out.println("(1) Login");
            System.out.println("(9) Sair");
            System.out.print("Opção: ");
            opcaoMenu = sc.nextInt();

            if (opcaoMenu == 1) {
                login();
            }
        }
    }

    public static void login() throws ParseException, SQLException {
        Scanner sc = new Scanner(System.in);
        System.out.print("E-mail: ");
        String email = sc.nextLine();
        System.out.print("Senha: ");
        String senha = sc.nextLine();
        AdmDAO admDAO = new AdmDAO();
        VendedorDAO vendedorDAO = new VendedorDAO();
        boolean admAutenticado = admDAO.autenticarAdm(email, senha);
        boolean vendedorAutenticado = vendedorDAO.autenticarVendedor(email, senha);

        if (admAutenticado) {
            menuAdm();
        } else if (vendedorAutenticado) {
            menuVendedor();
        } else {
            System.out.println("Email ou senha incorretos.");
        }
    }

    public static void menuAdm() throws ParseException {
        Scanner sc = new Scanner(System.in);
        int opcaoAdm = 0;
        while (opcaoAdm != 9) {
            System.out.println("⊹₊｡ꕤ˚₊⊹ MENU ADM ⊹₊｡ꕤ˚₊⊹");
            System.out.println("(1) Cadastrar");
            System.out.println("(2) Listar");
            System.out.println("(3) Fechamento do dia");
            System.out.println("(9) Sair");
            System.out.print("Opção: ");
            opcaoAdm = sc.nextInt();

            if (opcaoAdm == 1) {
                cadastrarAdm();
            } else if (opcaoAdm == 2) {
                listarAdm();
            } else if (opcaoAdm == 3) {
                Scanner sc2 = new Scanner(System.in);
                ControleFechamentoDia controleFechamentoDia = new ControleFechamentoDia();
                LocalDate dataFechamento = LocalDate.now();
                /*System.out.println("Digite o data desejada: ");
                System.out.print(" ☆ Dia: ");
                String dia = sc2.nextLine();
                System.out.print("☀ Mês: ");
                String mes = sc2.nextLine();
                System.out.print("☾ Ano: ");
                String ano = sc2.nextLine();
                String dataString = dia + "-" + mes + "-" + ano;
                DateTimeFormatter dataFormato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate dataFechamento = LocalDate.parse(dataString, dataFormato); */
                controleFechamentoDia.fechamentoDoDia(dataFechamento);
            }
        }
    }

    public static void menuVendedor() throws ParseException, SQLException {
        Scanner sc = new Scanner(System.in);
        int opcaoVendedor = 0;
        while (opcaoVendedor != 9) {
            System.out.println("⊹₊｡ꕤ˚₊⊹ MENU VENDEDOR ⊹₊｡ꕤ˚₊⊹");
            System.out.println("(1) Cadastrar");
            System.out.println("(2) Listar");
            System.out.println("(3) Fechamento do dia");
            System.out.println("(4) Registrar venda");
            System.out.println("(9) Sair");
            System.out.print("Opção: ");
            opcaoVendedor = sc.nextInt();

            if (opcaoVendedor == 1) {
                cadastrarVendedor();
            } else if (opcaoVendedor == 2) {
                listarVendedor();
            } else if (opcaoVendedor == 3) {
                ControleFechamentoDia controleFechamentoDia = new ControleFechamentoDia();
                LocalDate dataFechamento = LocalDate.now();
                /*System.out.println("Digite o data desejada: ");
                System.out.print(" ☆ Dia: ");
                String dia = sc.nextLine();
                System.out.print("☀ Mês: ");
                String mes = sc.nextLine();
                System.out.print("☾ Ano: ");
                String ano = sc.nextLine();
                String dataString = dia + "-" + mes + "-" + ano;
                DateTimeFormatter dataFormato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
                LocalDate dataFechamento = LocalDate.parse(dataString, dataFormato);*/
                controleFechamentoDia.fechamentoDoDia(dataFechamento);

            } else if (opcaoVendedor == 4) {
                novaVenda();
            }
        }
    }

    public static void cadastrarAdm() throws ParseException {
        Scanner sc = new Scanner(System.in);
        int opcaoCadastrarAdm = 0;
        while (opcaoCadastrarAdm != 9) {
            System.out.println("ᯓ★ CADASTRAR ᯓ★");
            System.out.println("(1) Cadastrar admin");
            System.out.println("(2) Cadastrar vendedor");
            System.out.println("(3) Cadastrar cliente");
            System.out.println("(4) Cadastrar fornecedor");
            System.out.println("(5) Cadastrar produto");
            System.out.println("(9) Sair");
            System.out.print("Opção: ");
            opcaoCadastrarAdm = sc.nextInt();

            if (opcaoCadastrarAdm == 1) {
                novoAdm();
            } else if (opcaoCadastrarAdm == 2) {
                novoVendedor();
            } else if (opcaoCadastrarAdm == 3) {
                novoCliente();
            } else if (opcaoCadastrarAdm == 4) {
                novoFornecedor();
            } else if (opcaoCadastrarAdm == 5) {
                novoProduto();
            }
        }
    }

    public static void listarAdm() {
        Scanner sc = new Scanner(System.in);
        int opcaoListarAdm = 0;
        int opcaoEditar = 0;
        while (opcaoListarAdm != 9) {
            System.out.println("ᯓ★ LISTAR ᯓ★");
            System.out.println("(1) Listar vendas");
            System.out.println("(2) Listar vendedor");
            System.out.println("(3) Listar cliente");
            System.out.println("(4) Listar fornecedor");
            System.out.println("(5) Listar produto");
            System.out.println("(9) Sair");
            System.out.print("Opção: ");
            opcaoListarAdm = sc.nextInt();

            while (opcaoEditar != 9) {
                if (opcaoListarAdm == 1) {
                    VendaDAO vvd = new VendaDAO();
                    vvd.listarVenda();
                    opcaoEditar = 9;

                } else if (opcaoListarAdm == 2) {
                    VendedorDAO vd = new VendedorDAO();
                    vd.listarVendedor();
                    System.out.println("(1) Editar");
                    System.out.println("(2) Apagar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarVendedor();
                    }
                    else if (opcaoEditar == 2) {
                        apagarVendedor();
                    }

                } else if (opcaoListarAdm == 3) {
                    ClienteDAO cd = new ClienteDAO();
                    cd.listarCliente();
                    System.out.println("(1) Editar");
                    System.out.println("(2) Apagar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarCliente();
                    }
                    else if (opcaoEditar == 2) {
                        apagarCliente();
                    }
                } else if (opcaoListarAdm == 4) {
                    FornecedorDAO fd = new FornecedorDAO();
                    fd.listarFornecedor();
                    System.out.println("(1) Editar");
                    System.out.println("(2) Apagar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarFornecedor();
                    }
                    else if (opcaoEditar == 2) {
                        apagarFornecedor();
                    }
                } else if (opcaoListarAdm == 5) {
                    ProdutoDAO pd = new ProdutoDAO();
                    pd.listarProduto();
                    System.out.println("(1) Editar");
                    System.out.println("(2) Apagar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarProduto();
                    }
                    else if (opcaoEditar == 2) {
                        apagarProduto();
                    }
                }
            }
        }
    }

    public static void cadastrarVendedor() throws ParseException {
        Scanner sc = new Scanner(System.in);
        int opcaoCadastrarVendedor = 0;
        while (opcaoCadastrarVendedor != 9) {
            System.out.println("ᯓ★ CADASTRAR ᯓ★");
            System.out.println("(1) Cadastrar cliente");
            System.out.println("(2) Cadastrar fornecedor");
            System.out.println("(3) Cadastrar produto");
            System.out.println("(9) Sair");
            System.out.print("Opção: ");
            opcaoCadastrarVendedor = sc.nextInt();

            if (opcaoCadastrarVendedor == 1) {
                novoCliente();
            } else if (opcaoCadastrarVendedor == 2) {
                novoFornecedor();
            } else if (opcaoCadastrarVendedor == 3) {
                novoProduto();
            }
        }
    }

    public static void listarVendedor() throws SQLException {
        Scanner sc = new Scanner(System.in);
        int opcaoListarVendedor = 0;
        int opcaoEditar = 0;
        while (opcaoListarVendedor != 9) {
            System.out.println("ᯓ★ LISTAR ᯓ★");
            System.out.println("(1) Listar vendas");
            System.out.println("(2) Listar vendedor");
            System.out.println("(3) Listar cliente");
            System.out.println("(4) Listar fornecedor");
            System.out.println("(5) Listar produto");
            System.out.println("(9) Sair");
            System.out.print("Opção: ");
            opcaoListarVendedor = sc.nextInt();

            while (opcaoEditar != 9) {
                if (opcaoListarVendedor == 1) {
                    VendaDAO vvd = new VendaDAO();
                    vvd.listarVenda();
                    opcaoEditar = 9;
                } else if (opcaoListarVendedor == 2) {
                    VendedorDAO vd = new VendedorDAO();
                    vd.listarVendedor();
                    System.out.println("(1) Editar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarVendedor();
                    }
                } else if (opcaoListarVendedor == 3) {
                    ClienteDAO cd = new ClienteDAO();
                    cd.listarCliente();
                    System.out.println("(1) Editar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarCliente();
                    }
                } else if (opcaoListarVendedor == 4) {
                    FornecedorDAO fd = new FornecedorDAO();
                    fd.listarFornecedor();
                    System.out.println("(1) Editar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarFornecedor();
                    }
                } else if (opcaoListarVendedor == 5) {
                    ProdutoDAO pd = new ProdutoDAO();
                    pd.listarProduto();
                    System.out.println("(1) Editar");
                    System.out.println("(9) Voltar");
                    System.out.print("Opção: ");
                    opcaoEditar = sc.nextInt();
                    if (opcaoEditar == 1) {
                        editarProduto();
                    }
                }
            }
        }
    }

    public static void novoAdm() {
        Scanner sc = new Scanner(System.in);
        System.out.println("˚₊‧꒰ა NOVO ADMIN ໒꒱ ‧₊˚");
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Nome: ");
        String nome = sc.nextLine();
        System.out.print("˖◛⁺⑅♡ Email: ");
        String email = sc.nextLine();
        System.out.print("\uD83D\uDDDD Senha: ");
        String senha = sc.nextLine();
        Adm adm = new Adm(nome, email, senha);
        AdmDAO ad = new AdmDAO();
        ad.inserirAdm(adm);
    }

    public static void novoCliente() throws ParseException {
        Scanner sc = new Scanner(System.in);
        System.out.println("˚₊‧꒰ა NOVO CLIENTE ໒꒱ ‧₊˚");
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Nome: ");
        String nome = sc.nextLine();
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Sobrenome: ");
        String sobrenome = sc.nextLine();
        System.out.println("♡\uD83D\uDDD2♡ Data de nascimento: ");
        System.out.print(" ☆ Dia: ");
        String dia = sc.nextLine();
        System.out.print("☀ Mês: ");
        String mes = sc.nextLine();
        System.out.print("☾ Ano: ");
        String ano = sc.nextLine();
        String dataString = dia + "-" + mes + "-" + ano;
        DateTimeFormatter dataFormato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate dataNascimento = LocalDate.parse(dataString, dataFormato);
        System.out.print("☏ Telefone: ");
        String telefone = sc.nextLine();
        System.out.print("\uD83C\uDC23 CPF: ");
        String cpf = sc.nextLine();
        System.out.print("⾕ Cidade: ");
        String cidade = sc.nextLine();
        System.out.print("ᨒ Estado: ");
        String estado = sc.nextLine();
        System.out.print("\uD83D\uDDFA País: ");
        String pais = sc.nextLine();
        System.out.print(" ⟟ Endereço: ");
        String endereco = sc.nextLine();
        System.out.print("\uD835\uDFDA Número: ");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.print("˖◛⁺⑅♡ Email: ");
        String email = sc.nextLine();
        System.out.print("\uD83D\uDDDD Senha: ");
        String senha = sc.nextLine();
        LocalDateTime dataCadastro = LocalDateTime.now();
        Cliente c = new Cliente(nome, sobrenome, dataNascimento, telefone, cpf, cidade, estado, pais, endereco, numero, email, senha, dataCadastro);
        ClienteDAO cd = new ClienteDAO();
        cd.inserirCliente(c);

    }

    public static void novoVendedor() throws ParseException {
        Scanner sc = new Scanner(System.in);
        System.out.println("˚₊‧꒰ა NOVO VENDEDOR ໒꒱ ‧₊˚");
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Nome: ");
        String nome = sc.nextLine();
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Sobrenome: ");
        String sobrenome = sc.nextLine();
        System.out.println("♡\uD83D\uDDD2♡ Data de nascimento: ");
        System.out.print(" ☆ Dia: ");
        String dia = sc.nextLine();
        System.out.print("☀ Mês: ");
        String mes = sc.nextLine();
        System.out.print("☾ Ano: ");
        String ano = sc.nextLine();
        String dataString = dia + "-" + mes + "-" + ano;
        DateTimeFormatter dataFormato = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate dataNascimento = LocalDate.parse(dataString, dataFormato);
        System.out.print("☏ Telefone: ");
        String telefone = sc.nextLine();
        System.out.print("\uD83C\uDC23 CPF: ");
        String cpf = sc.nextLine();
        System.out.print("⾕ Cidade: ");
        String cidade = sc.nextLine();
        System.out.print("ᨒ Estado: ");
        String estado = sc.nextLine();
        System.out.print("\uD83D\uDDFA País: ");
        String pais = sc.nextLine();
        System.out.print(" ⟟ Endereço: ");
        String endereco = sc.nextLine();
        System.out.print("\uD835\uDFDA Número: ");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.print("˖◛⁺⑅♡ Email: ");
        String email = sc.nextLine();
        System.out.print("\uD83D\uDDDD Senha: ");
        String senha = sc.nextLine();
        LocalDateTime dataCadastro = LocalDateTime.now();
        Vendedor v = new Vendedor(nome, sobrenome, dataNascimento, telefone, cpf, cidade, estado, pais, endereco, numero, email, senha, dataCadastro);
        VendedorDAO vd = new VendedorDAO();
        vd.inserirVendedor(v);
    }

    public static void novoFornecedor() {
        Scanner sc = new Scanner(System.in);
        System.out.println("˚₊‧꒰ა NOVO FORNECEDOR ໒꒱ ‧₊˚");
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Nome Fantasia: ");
        String nomeFantasia = sc.nextLine();
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Razão Social: ");
        String razaoSocial = sc.nextLine();
        System.out.print("☏ Telefone: ");
        String telefone = sc.nextLine();
        System.out.print("\uD83C\uDC23 CNPJ: ");
        String cnpj = sc.nextLine();
        System.out.print("⾕ Cidade: ");
        String cidade = sc.nextLine();
        System.out.print("ᨒ Estado: ");
        String estado = sc.nextLine();
        System.out.print("\uD83D\uDDFA País: ");
        String pais = sc.nextLine();
        System.out.print(" ⟟ Endereço: ");
        String endereco = sc.nextLine();
        System.out.print("\uD835\uDFDA Número: ");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.print("˖◛⁺⑅♡ Email: ");
        String email = sc.nextLine();
        System.out.print("\uD83D\uDDDD Senha: ");
        String senha = sc.nextLine();
        LocalDateTime dataCadastro = LocalDateTime.now();
        Fornecedor f = new Fornecedor(nomeFantasia, razaoSocial, telefone, cnpj, cidade, estado, pais, endereco, numero, email, senha, dataCadastro);
        FornecedorDAO fd = new FornecedorDAO();
        fd.inserirFornecedor(f);
    }

    public static void novoProduto() {
        Scanner sc = new Scanner(System.in);
        System.out.println("˚₊‧꒰ა NOVO PRODUTO ໒꒱ ‧₊˚");
        System.out.print("\uD80C\uDC83\uD83D\uDD8A Descrição: ");
        String descricao = sc.nextLine();
        System.out.print("\uD835\uDFDA Quantidade: ");
        int qtde = sc.nextInt();
        sc.nextLine();
        System.out.print("\uD81A\uDD18 Preço: ");
        float preco = sc.nextFloat();
        sc.nextLine();
        System.out.print("\uD83C\uDFD9 ID do Fornecedor: ");
        int fornecedor = sc.nextInt();
        Produto p = new Produto(descricao, qtde, preco, fornecedor);
        ProdutoDAO pd = new ProdutoDAO();
        pd.inserirProduto(p);
    }

    public static void novaVenda() throws SQLException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o ID do cliente:");
        int idCliente = sc.nextInt();
        sc.nextLine();
        System.out.println("Digite o ID do vendedor:");
        int idVendedor = sc.nextInt();
        sc.nextLine();
        System.out.println("Digite o ID da forma de pagamento (Crédito - 1, Débito - 2, Dinheiro - 3):");
        int idFormaPagamento = sc.nextInt();
        sc.nextLine();

        int parcelas = 1; // Inicialmente definido como 1
        if (idFormaPagamento == 1) {
            System.out.println("Digite o número de parcelas (máximo 10):");
            parcelas = sc.nextInt();
            sc.nextLine();
            if (parcelas > 10) {
                parcelas = 10;
            }
        }

        ArrayList<ItemVenda> itens = new ArrayList<>();
        boolean adicionarMaisItens = true;
        VendaDAO vendaDAO = new VendaDAO();
        while (adicionarMaisItens) {
            System.out.println("Digite o ID do produto:");
            int idProduto = sc.nextInt();
            sc.nextLine();
            float precoUnitario = (float) vendaDAO.consultarPrecoUnitarioProduto(idProduto);
            String produtoNome = vendaDAO.consultarNomeProduto(idProduto);
            System.out.println("Digite a quantidade:");
            int quantidade = sc.nextInt();
            sc.nextLine();
            float valorItem = precoUnitario * quantidade;
            itens.add(new ItemVenda(idProduto, produtoNome, quantidade, precoUnitario, valorItem));
            System.out.println("Deseja adicionar mais itens? (s/n)");
            String resposta = sc.next();
            adicionarMaisItens = resposta.equalsIgnoreCase("s");
        }

        boolean sucesso = vendaDAO.registrarVenda(idCliente, idVendedor, idFormaPagamento, itens, parcelas);
        if (sucesso) {
            System.out.println("Venda registrada com sucesso!");
        } else {
            System.out.println("Falha ao registrar a venda.");
        }
    }


    private static void editarVendedor() {
        Scanner sc = new Scanner(System.in);
        VendedorDAO vendedorDAO = new VendedorDAO();
        System.out.println("Informe o ID do vendedor que deseja editar:");
        int idVendedor = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe o nome (ou deixe vazio para manter o atual):");
        String nome = sc.nextLine();
        System.out.println("Informe o sobrenome (ou deixe vazio para manter o atual):");
        String sobrenome = sc.nextLine();
        System.out.println("Informe a data de nascimento (yyyy-MM-dd) (ou deixe vazio para manter a atual):");
        String dataNascimentoStr = sc.nextLine();
        LocalDate dataNascimento = dataNascimentoStr.isEmpty() ? null : LocalDate.parse(dataNascimentoStr);
        System.out.println("Informe o telefone (ou deixe vazio para manter o atual):");
        String telefone = sc.nextLine();
        System.out.println("Informe o CPF (ou deixe vazio para manter o atual):");
        String CPF = sc.nextLine();
        System.out.println("Informe a cidade (ou deixe vazio para manter a atual):");
        String cidade = sc.nextLine();
        System.out.println("Informe o estado (ou deixe vazio para manter o atual):");
        String estado = sc.nextLine();
        System.out.println("Informe o país (ou deixe vazio para manter o atual):");
        String pais = sc.nextLine();
        System.out.println("Informe o endereço (ou deixe vazio para manter o atual):");
        String endereco = sc.nextLine();
        System.out.println("Informe o número (ou 0 para manter o atual):");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe o email (ou deixe vazio para manter o atual):");
        String email = sc.nextLine();
        System.out.println("Informe a senha (ou deixe vazio para manter a atual):");
        String senha = sc.nextLine();
        Vendedor vendedor = new Vendedor();
        vendedor.setNome(nome.isEmpty() ? null : nome);
        vendedor.setSobrenome(sobrenome.isEmpty() ? null : sobrenome);
        vendedor.setDataNascimento(dataNascimento);
        vendedor.setTelefone(telefone.isEmpty() ? null : telefone);
        vendedor.setCPF(CPF.isEmpty() ? null : CPF);
        vendedor.setCidade(cidade.isEmpty() ? null : cidade);
        vendedor.setEstado(estado.isEmpty() ? null : estado);
        vendedor.setPais(pais.isEmpty() ? null : pais);
        vendedor.setEndereco(endereco.isEmpty() ? null : endereco);
        vendedor.setNumero(numero == 0 ? 0 : numero);
        vendedor.setEmail(email.isEmpty() ? null : email);
        vendedor.setSenha(senha.isEmpty() ? null : senha);
        vendedorDAO.editarVendedor(idVendedor, vendedor);
    }

    private static void editarCliente() {
        Scanner sc = new Scanner(System.in);
        ClienteDAO clienteDAO = new ClienteDAO();
        System.out.println("Informe o ID do cliente que deseja editar:");
        int idCliente = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe o nome (ou deixe vazio para manter o atual):");
        String nome = sc.nextLine();
        System.out.println("Informe o sobrenome (ou deixe vazio para manter o atual):");
        String sobrenome = sc.nextLine();
        System.out.println("Informe a data de nascimento (yyyy-MM-dd) (ou deixe vazio para manter a atual):");
        String dataNascimentoStr = sc.nextLine();
        LocalDate dataNascimento = dataNascimentoStr.isEmpty() ? null : LocalDate.parse(dataNascimentoStr);
        System.out.println("Informe o telefone (ou deixe vazio para manter o atual):");
        String telefone = sc.nextLine();
        System.out.println("Informe o CPF (ou deixe vazio para manter o atual):");
        String CPF = sc.nextLine();
        System.out.println("Informe a cidade (ou deixe vazio para manter a atual):");
        String cidade = sc.nextLine();
        System.out.println("Informe o estado (ou deixe vazio para manter o atual):");
        String estado = sc.nextLine();
        System.out.println("Informe o país (ou deixe vazio para manter o atual):");
        String pais = sc.nextLine();
        System.out.println("Informe o endereço (ou deixe vazio para manter o atual):");
        String endereco = sc.nextLine();
        System.out.println("Informe o número (ou 0 para manter o atual):");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe o email (ou deixe vazio para manter o atual):");
        String email = sc.nextLine();
        System.out.println("Informe a senha (ou deixe vazio para manter a atual):");
        String senha = sc.nextLine();
        Cliente cliente = new Cliente();
        cliente.setNome(nome.isEmpty() ? null : nome);
        cliente.setSobrenome(sobrenome.isEmpty() ? null : sobrenome);
        cliente.setDataNascimento(dataNascimento);
        cliente.setTelefone(telefone.isEmpty() ? null : telefone);
        cliente.setCPF(CPF.isEmpty() ? null : CPF);
        cliente.setCidade(cidade.isEmpty() ? null : cidade);
        cliente.setEstado(estado.isEmpty() ? null : estado);
        cliente.setPais(pais.isEmpty() ? null : pais);
        cliente.setEndereco(endereco.isEmpty() ? null : endereco);
        cliente.setNumero(numero == 0 ? 0 : numero);
        cliente.setEmail(email.isEmpty() ? null : email);
        cliente.setSenha(senha.isEmpty() ? null : senha);
        clienteDAO.editarCliente(idCliente, cliente);
    }

    private static void editarFornecedor() {
        Scanner sc = new Scanner(System.in);
        FornecedorDAO fornecedorDAO = new FornecedorDAO();
        System.out.println("Informe o ID do fornecedor que deseja editar:");
        int idFornecedor = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe o nome fantasia (ou deixe vazio para manter o atual):");
        String nomeFantasia = sc.nextLine();
        System.out.println("Informe a razão social (ou deixe vazio para manter o atual):");
        String razaoSocial = sc.nextLine();
        System.out.println("Informe o telefone (ou deixe vazio para manter o atual):");
        String telefone = sc.nextLine();
        System.out.println("Informe o CNPJ (ou deixe vazio para manter o atual):");
        String CNPJ = sc.nextLine();
        System.out.println("Informe a cidade (ou deixe vazio para manter a atual):");
        String cidade = sc.nextLine();
        System.out.println("Informe o estado (ou deixe vazio para manter o atual):");
        String estado = sc.nextLine();
        System.out.println("Informe o país (ou deixe vazio para manter o atual):");
        String pais = sc.nextLine();
        System.out.println("Informe o endereço (ou deixe vazio para manter o atual):");
        String endereco = sc.nextLine();
        System.out.println("Informe o número (ou 0 para manter o atual):");
        int numero = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe o email (ou deixe vazio para manter o atual):");
        String email = sc.nextLine();
        System.out.println("Informe a senha (ou deixe vazio para manter a atual):");
        String senha = sc.nextLine();
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setNomeFantasia(nomeFantasia.isEmpty() ? null : nomeFantasia);
        fornecedor.setRazaoSocial(razaoSocial.isEmpty() ? null : razaoSocial);
        fornecedor.setTelefone(telefone.isEmpty() ? null : telefone);
        fornecedor.setCNPJ(CNPJ.isEmpty() ? null : CNPJ);
        fornecedor.setCidade(cidade.isEmpty() ? null : cidade);
        fornecedor.setEstado(estado.isEmpty() ? null : estado);
        fornecedor.setPais(pais.isEmpty() ? null : pais);
        fornecedor.setEndereco(endereco.isEmpty() ? null : endereco);
        fornecedor.setNumero(numero == 0 ? 0 : numero);
        fornecedor.setEmail(email.isEmpty() ? null : email);
        fornecedor.setSenha(senha.isEmpty() ? null : senha);
        fornecedorDAO.editarFornecedor(idFornecedor, fornecedor);
    }

    private static void editarProduto() {
        Scanner sc = new Scanner(System.in);
        ProdutoDAO produtoDAO = new ProdutoDAO();
        System.out.println("Informe o ID do produto que deseja editar:");
        int idProduto = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe a descrição (ou deixe vazio para manter o atual):");
        String descricao = sc.nextLine();
        System.out.println("Informe a quantidade:");
        int quantidade = sc.nextInt();
        sc.nextLine();
        System.out.println("Informe o preço (ou 0 para manter o atual):");
        Double preco = sc.nextDouble();
        sc.nextLine();
        System.out.println("Informe o id do fornecedor (ou 0 para manter o atual):");
        int fornecedor = sc.nextInt();
        sc.nextLine();

        Produto produto = new Produto();
        produto.setDescricao(descricao.isEmpty() ? null : descricao);
        produto.setQuantidade(quantidade == 0 ? 0 : quantidade);
        produto.setPreco(preco == 0 ? 0 : quantidade);
        produto.setIdFornecedor(fornecedor == 0 ? 0 : fornecedor);
        produtoDAO.editarProduto(idProduto, produto);
    }

    private static void apagarVendedor() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Informe o ID do vendedor que deseja apagar:");
        int idVendedor = sc.nextInt();
        VendedorDAO vd = new VendedorDAO();
        vd.apagarVendedor(idVendedor);
    }

    private static void apagarCliente() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Informe o ID do vendedor que deseja apagar:");
        int idCliente = sc.nextInt();
        ClienteDAO cd = new ClienteDAO();
        cd.apagarCliente(idCliente);
    }
    private static void apagarFornecedor() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Informe o ID do vendedor que deseja apagar:");
        int idFornecedor = sc.nextInt();
        FornecedorDAO fd = new FornecedorDAO();
        fd.apagarFornecedor(idFornecedor);
    }

    private static void apagarProduto() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Informe o ID do produto que deseja apagar:");
        int idProduto = sc.nextInt();
        ProdutoDAO pd = new ProdutoDAO();
        pd.apagarProduto(idProduto);
    }
}

