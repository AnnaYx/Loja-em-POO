package dao;

import java.sql.*;

import model.Adm;


public class AdmDAO {
    private Conexao conexao = Conexao.getConexao();
    private String query;
    private PreparedStatement ps;
    private ResultSet rs;

    public AdmDAO() {
        conexao = Conexao.getConexao();
    }

    public void inserirAdm(Adm a) {
        this.query = "INSERT INTO adm(nome, email, senha) VALUES (?, ?, ?)";

        try {
            this.ps = this.conexao.getConnection().prepareStatement(this.query);
            this.ps.setString(1, a.getNome());
            this.ps.setString(2, a.getEmail());
            this.ps.setString(3, a.getSenha());
            this.ps.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public boolean autenticarAdm(String email, String senha) {
        String query = "SELECT * FROM poo.admin WHERE email = ? AND senha = ?";

        try {
            PreparedStatement ps = conexao.getConnection().prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, senha);

            ResultSet rs = ps.executeQuery();
            return rs.next(); // Retorna true se existir uma linha correspondente no resultado
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}