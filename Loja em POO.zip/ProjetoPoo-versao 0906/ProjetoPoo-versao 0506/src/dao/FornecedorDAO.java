package dao;

import model.Cliente;
import model.Fornecedor;
import model.Vendedor;

import java.sql.*;

public class FornecedorDAO {

    private Conexao conexao;
    private static String query;
    private PreparedStatement ps;

    public FornecedorDAO() {
        conexao = Conexao.getConexao();
    }

    public void inserirFornecedor(Fornecedor f) {

        this.query = "INSERT INTO poo.fornecedor(nomeFantasia, razaoSocial, telefone, CNPJ, cidade, estado, pais, endereco, numero, email, senha, dataCadastro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try{
            this.ps = conexao.getConnection().prepareStatement(this.query);
            this.ps.setString(1, f.getNomeFantasia());
            this.ps.setString(2, f.getRazaoSocial());
            this.ps.setString(3, f.getTelefone());
            this.ps.setString(4, f.getCNPJ());
            this.ps.setString(5, f.getCidade());
            this.ps.setString(6, f.getEstado());
            this.ps.setString(7, f.getPais());
            this.ps.setString(8, f.getEndereco());
            this.ps.setInt(9, f.getNumero());
            this.ps.setString(10, f.getEmail());
            this.ps.setString(11, f.getSenha());
            this.ps.setTimestamp(12, Timestamp.valueOf(f.getDataCadastro()));
            this.ps.executeUpdate();
            this.ps.close();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void listarFornecedor() {
        this.query = "SELECT * FROM poo.fornecedor";
        try {
            this.ps = conexao.getConnection().prepareStatement(this.query);
            ResultSet rs = ps.executeQuery();

            // Iterando sobre os resultados
            while (rs.next()) {
                int id = rs.getInt("id_fornecedor");
                String nomeFantasia = rs.getString("nomeFantasia");
                String razaoSocial = rs.getString("razaoSocial");
                String telefone = rs.getString("telefone");
                String cnpj = rs.getString("CNPJ");
                String cidade = rs.getString("cidade");
                String estado = rs.getString("estado");
                String pais = rs.getString("pais");
                String endereco = rs.getString("endereco");
                int numero = rs.getInt("numero");
                Timestamp dataCadastro = rs.getTimestamp("dataCadastro");
                String email = rs.getString("email");
                String senha = rs.getString("senha");

                // Imprimindo os resultados
                System.out.println("ID: " + id);
                System.out.println("Nome Fantasia: " + nomeFantasia);
                System.out.println("Razão Social: " + razaoSocial);
                System.out.println("Telefone: " + telefone);
                System.out.println("CNPJ: " + cnpj);
                System.out.println("Cidade: " + cidade);
                System.out.println("Estado: " + estado);
                System.out.println("País: " + pais);
                System.out.println("Endereço: " + endereco);
                System.out.println("Número: " + numero);
                System.out.println("Data de Cadastro: " + dataCadastro);
                System.out.println("Email: " + email);
                System.out.println("Senha: " + senha);
                System.out.println("-------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void editarFornecedor(int id, Fornecedor f) {
        String selectQuery = "SELECT * FROM poo.fornecedor WHERE id_fornecedor = ?";
        String updateQuery = "UPDATE poo.fornecedor SET nomeFantasia = ?, razaoSocial = ?, telefone = ?, CNPJ = ?, cidade = ?, estado = ?, pais = ?, endereco = ?, numero = ?, email = ?, senha = ? WHERE id_fornecedor = ?";

        try {
            // Primeiro, seleciona o vendedor pelo ID
            PreparedStatement psSelect = conexao.getConnection().prepareStatement(selectQuery);
            psSelect.setInt(1, id);
            ResultSet rs = psSelect.executeQuery();

            if (rs.next()) {
                // Se o vendedor com o ID especificado for encontrado, obtenha os dados atuais
                String nomeAtual = rs.getString("nomeFantasia");
                String razaoAtual = rs.getString("razaoSocial");
                String telefoneAtual = rs.getString("telefone");
                String cnpjAtual = rs.getString("CNJP");
                String cidadeAtual = rs.getString("cidade");
                String estadoAtual = rs.getString("estado");
                String paisAtual = rs.getString("pais");
                String enderecoAtual = rs.getString("endereco");
                int numeroAtual = rs.getInt("numero");
                String emailAtual = rs.getString("email");
                String senhaAtual = rs.getString("senha");

                // Verifica se os novos valores foram fornecidos e se são diferentes dos atuais
                String novoNome = (f.getNomeFantasia() != null) ? f.getNomeFantasia() : nomeAtual;
                String novaRazao = (f.getRazaoSocial() != null) ? f.getRazaoSocial() : razaoAtual;
                String novoTelefone = (f.getTelefone() != null) ? f.getTelefone() : telefoneAtual;
                String novoCnpj = (f.getCNPJ() != null) ? f.getCNPJ() : cnpjAtual;
                String novaCidade = (f.getCidade() != null) ? f.getCidade() : cidadeAtual;
                String novoEstado = (f.getEstado() != null) ? f.getEstado() : estadoAtual;
                String novoPais = (f.getPais() != null) ? f.getPais() : paisAtual;
                String novoEndereco = (f.getEndereco() != null) ? f.getEndereco() : enderecoAtual;
                int novoNumero = (f.getNumero() != 0) ? f.getNumero() : numeroAtual;
                String novoEmail = (f.getEmail() != null) ? f.getEmail() : emailAtual;
                String novaSenha = (f.getSenha() != null) ? f.getSenha() : senhaAtual;

                PreparedStatement psUpdate = conexao.getConnection().prepareStatement(updateQuery);
                psUpdate.setString(1, novoNome);
                psUpdate.setString(2, novaRazao);
                psUpdate.setString(3, novoTelefone);
                psUpdate.setString(4, novoCnpj);
                psUpdate.setString(5, novaCidade);
                psUpdate.setString(6, novoEstado);
                psUpdate.setString(7, novoPais);
                psUpdate.setString(8, novoEndereco);
                psUpdate.setInt(9, novoNumero);
                psUpdate.setString(10, novoEmail);
                psUpdate.setString(11, novaSenha);
                psUpdate.setInt(12, id);

                // Executa a atualização
                int linhasAfetadas = psUpdate.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Fornecedor com ID " + id + " atualizado com sucesso!");
                } else {
                    System.out.println("Falha ao atualizar o fornecedor com ID " + id);
                }
            } else {
                System.out.println("Fornecedor com ID " + id + " não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void apagarFornecedor(int id) {
        String deleteQuery = "DELETE FROM poo.fornecedor WHERE id_fornecedor = ?";

        try {
            Connection conn = conexao.getConnection();
            PreparedStatement ps = conn.prepareStatement(deleteQuery);
            ps.setInt(1, id);

            int linhasAfetadas = ps.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Fornecedor com ID " + id + " apagado com sucesso!");
            } else {
                System.out.println("Falha ao apagar o fornecedor com ID " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
