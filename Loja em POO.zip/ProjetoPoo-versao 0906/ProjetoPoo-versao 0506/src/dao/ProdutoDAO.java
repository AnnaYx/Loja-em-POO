package dao;

import model.Produto;

import java.sql.*;

public class ProdutoDAO {
    private Conexao conexao;
    private String query;
    private PreparedStatement ps;

    public ProdutoDAO() {
        conexao = Conexao.getConexao();
    }

    public void inserirProduto(Produto p) {

        this.query = "INSERT INTO poo.produto(descricao, quantidade, preco, fornecedor) VALUES (?,?,?,?)";
        try {
            this.ps = conexao.getConnection().prepareStatement(this.query);
            this.ps.setString(1, p.getDescricao());
            this.ps.setInt(2, p.getQuantidade());
            this.ps.setFloat(3, p.getPreco());
            this.ps.setInt(4, p.getIdFornecedor());
            this.ps.executeUpdate();
            this.ps.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }
    public void listarProduto() {
        this.query = "SELECT * FROM poo.produto";
        try {
            this.ps = conexao.getConnection().prepareStatement(this.query);
            ResultSet rs = ps.executeQuery();

            // Iterando sobre os resultados
            while (rs.next()) {
                int id = rs.getInt("id_produto");
                String descricao = rs.getString("descricao");
                int qtde = rs.getInt("quantidade");
                float preco = rs.getFloat("preco");
                // Imprimindo os resultados
                System.out.println("ID: " + id);
                System.out.println("Descrição: " + descricao);
                System.out.println("Quantidade: " + qtde);
                System.out.println("Preco: " + preco);
                System.out.println("-------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void editarProduto(int id, Produto p) {
        String selectQuery = "SELECT * FROM poo.produto WHERE id_produto = ?";
        String updateQuery = "UPDATE poo.produto SET descricao = ?, quantidade = ?, preco = ?, fornecedor = ? WHERE id_produto = ?";

        try {
            PreparedStatement psSelect = conexao.getConnection().prepareStatement(selectQuery);
            psSelect.setInt(1, id);
            ResultSet rs = psSelect.executeQuery();

            if (rs.next()) {
                String descricaoAtual = rs.getString("descricao");
                int quantidadeAtual = rs.getInt("quantidade");
                float precoAtual = rs.getFloat("preco");
                int fornecedorAtual = rs.getInt("fornecedor");

                // Verifica se os novos valores foram fornecidos e se são diferentes dos atuais
                String novaDescricao = (p.getDescricao() != null) ? p.getDescricao() : descricaoAtual;
                int novaQuantidade = (p.getQuantidade() != 0) ? p.getQuantidade() : quantidadeAtual;
                float novoPreco = (p.getPreco() != 0) ? p.getPreco() : precoAtual;
                int novoFornecedor = (p.getIdFornecedor() != 0) ? p.getIdFornecedor() : fornecedorAtual;

                PreparedStatement psUpdate = conexao.getConnection().prepareStatement(updateQuery);
                psUpdate.setString(1, novaDescricao);
                psUpdate.setInt(2, novaQuantidade);
                psUpdate.setDouble(3, novoPreco);
                psUpdate.setInt(4, novoFornecedor);
                psUpdate.setInt(5, id);

                // Executa a atualização
                int linhasAfetadas = psUpdate.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Vendedor com ID " + id + " atualizado com sucesso!");
                } else {
                    System.out.println("Falha ao atualizar o vendedor com ID " + id);
                }
            } else {
                System.out.println("Vendedor com ID " + id + " não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void apagarProduto(int id) {
        String deleteQuery = "DELETE FROM poo.produto WHERE id_produto = ?";

        try {
            Connection conn = conexao.getConnection();
            PreparedStatement ps = conn.prepareStatement(deleteQuery);
            ps.setInt(1, id);

            int linhasAfetadas = ps.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Vendedor com ID " + id + " apagado com sucesso!");
            } else {
                System.out.println("Falha ao apagar o vendedor com ID " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

