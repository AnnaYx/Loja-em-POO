package dao;

import model.Cliente;
import model.ItemVenda;
import model.Venda;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import java.sql.*;
import java.util.List;

public class VendaDAO {
    private Conexao conexao;
    private static String query;
    private PreparedStatement ps;

    public VendaDAO() {
        conexao = Conexao.getConexao();
    }

    public boolean registrarVenda(int idCliente, int idVendedor, int idFormaPagamento, List<ItemVenda> itens, int parcelas) {
        String queryVenda = "INSERT INTO venda (data_venda, id_cliente, id_vendedor, id_forma_pagamento, valor_total) VALUES (?, ?, ?, ?, ?)";
        String queryItem = "INSERT INTO itens (id_venda, id_produto, quantidade, preco_unitario) VALUES (?, ?, ?, ?)";
        String queryUpdateEstoque = "UPDATE produto SET quantidade = quantidade - ? WHERE id_produto = ?";

        try {
            // Iniciar transação
            conexao.getConnection().setAutoCommit(false);

            // Calcular o valor total da venda
            double valorTotal = 0.0;
            for (ItemVenda item : itens) {
                valorTotal += item.getPrecoUnitario() * item.getQuantidade();
            }

            // Verificar as condições de parcelamento
            if (idFormaPagamento == 1) {
                if (valorTotal > 1000 && parcelas > 5) {
                    // Aplicar juros de 5% se parcelar em mais de 5 vezes
                    valorTotal *= 1.05;
                }
                // Limitar o número de parcelas a no máximo 10
                if (parcelas > 10) {
                    parcelas = 10;
                }
            } else {
                // Se não for pagamento a crédito, não permitir parcelamento
                parcelas = 1;
            }

            // Inserir a venda
            PreparedStatement psVenda = conexao.getConnection().prepareStatement(queryVenda, Statement.RETURN_GENERATED_KEYS);
            psVenda.setDate(1, new java.sql.Date(System.currentTimeMillis()));
            psVenda.setInt(2, idCliente);
            psVenda.setInt(3, idVendedor);
            psVenda.setInt(4, idFormaPagamento);
            psVenda.setDouble(5, valorTotal);
            psVenda.executeUpdate();

            // Obter o ID da venda gerado
            ResultSet rs = psVenda.getGeneratedKeys();
            int idVenda = 0;
            if (rs.next()) {
                idVenda = rs.getInt(1);
            }

            // Inserir os itens da venda
            PreparedStatement psItem = conexao.getConnection().prepareStatement(queryItem);
            for (ItemVenda item : itens) {
                psItem.setInt(1, idVenda);
                psItem.setInt(2, item.getIdProduto());
                psItem.setInt(3, item.getQuantidade());
                psItem.setDouble(4, item.getPrecoUnitario());
                psItem.executeUpdate();

                // Atualizar o estoque do produto
                PreparedStatement psUpdateEstoque = conexao.getConnection().prepareStatement(queryUpdateEstoque);
                psUpdateEstoque.setInt(1, item.getQuantidade());
                psUpdateEstoque.setInt(2, item.getIdProduto());
                psUpdateEstoque.executeUpdate();
            }

            // Commit da transação
            conexao.getConnection().commit();
            return true;
        } catch (SQLException e) {
            try {
                // Rollback da transação em caso de erro
                conexao.getConnection().rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                conexao.getConnection().setAutoCommit(true);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


    public void listarVenda() {
        this.query = "SELECT v.id_venda, v.data_venda, " +
                "c.nome AS cliente_nome, " +
                "vd.nome AS vendedor_nome, " +
                "fp.descricao AS forma_pagamento, " +
                "p.descricao AS produto_nome, " +
                "i.quantidade, " +
                "p.preco, " +
                "(p.preco * i.quantidade) AS valor_item, " +
                "(SELECT SUM(p.preco * i.quantidade) " +
                " FROM poo.itens i " +
                " JOIN poo.produto p ON p.id_produto = i.id_produto " +
                " WHERE i.id_venda = v.id_venda) AS valor_total_venda " +
                "FROM poo.venda v " +
                "JOIN poo.itens i ON i.id_venda = v.id_venda " +
                "JOIN poo.produto p ON p.id_produto = i.id_produto " +
                "JOIN poo.cliente c ON c.id_cliente = v.id_cliente " +
                "JOIN poo.vendedor vd ON vd.id_vendedor = v.id_vendedor " +
                "JOIN poo.forma_pagamento fp ON fp.id_forma_pagamento = v.id_forma_pagamento " +
                "ORDER BY v.id_venda";

        try {
            this.ps = conexao.getConnection().prepareStatement(this.query);
            ResultSet rs = ps.executeQuery();

            Map<Integer, ArrayList<ItemVenda>> vendas = new HashMap<>();

            while (rs.next()) {
                int idVenda = rs.getInt("id_venda");
                Date dataVenda = rs.getDate("data_venda");
                String clienteNome = rs.getString("cliente_nome");
                String vendedorNome = rs.getString("vendedor_nome");
                String formaPagamento = rs.getString("forma_pagamento");
                String produtoNome = rs.getString("produto_nome");
                int quantidade = rs.getInt("quantidade");
                float preco = rs.getFloat("preco");
                float valorItem = rs.getFloat("valor_item");
                float valorTotalVenda = rs.getFloat("valor_total_venda");

                // Criar objeto ItemVenda para cada linha
                ItemVenda itemVenda = new ItemVenda(produtoNome, quantidade, preco, valorItem);
                itemVenda.setDataVenda(dataVenda);
                itemVenda.setClienteNome(clienteNome);
                itemVenda.setVendedorNome(vendedorNome);
                itemVenda.setFormaPagamento(formaPagamento);
                itemVenda.setValorTotalVenda(valorTotalVenda);

                // Adicionar ItemVenda na lista correspondente à venda
                if (!vendas.containsKey(idVenda)) {
                    vendas.put(idVenda, new ArrayList<>());
                }
                vendas.get(idVenda).add(itemVenda);
            }

            // Agora, vamos imprimir os dados formatados
            for (Map.Entry<Integer, ArrayList<ItemVenda>> entry : vendas.entrySet()) {
                int idVenda = entry.getKey();
                System.out.println("Venda ID: " + idVenda);

                // Imprimir dados gerais da venda apenas uma vez
                ItemVenda primeiroItem = entry.getValue().get(0);
                System.out.println("Data: " + primeiroItem.getDataVenda());
                System.out.println("Cliente: " + primeiroItem.getClienteNome());
                System.out.println("Vendedor: " + primeiroItem.getVendedorNome());
                System.out.println("Forma de Pagamento: " + primeiroItem.getFormaPagamento());

                // Imprimir detalhes dos itens da venda
                for (ItemVenda item : entry.getValue()) {
                    System.out.println("Produto: " + item.getProdutoNome());
                    System.out.println("Quantidade: " + item.getQuantidade());
                    System.out.println("Preço Unitário: " + item.getPrecoUnitario());
                    System.out.println("Valor Item: " + item.getValorItem());
                }

                // Imprimir total da venda
                System.out.println("Total da Venda: " + primeiroItem.getValorTotalVenda());
                System.out.println("-----------");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public double consultarPrecoUnitarioProduto(int idProduto) throws SQLException {
        String query = "SELECT preco FROM produto WHERE id_produto = ?";
        try (PreparedStatement ps = conexao.getConnection().prepareStatement(query)) {
            ps.setInt(1, idProduto);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getDouble("preco");
            }
        }
        throw new SQLException("Produto não encontrado com o ID: " + idProduto);
    }

    // Método para consultar o nome do produto no banco de dados
    public String consultarNomeProduto(int idProduto) throws SQLException {
        String query = "SELECT descricao FROM produto WHERE id_produto = ?";
        try (PreparedStatement ps = conexao.getConnection().prepareStatement(query)) {
            ps.setInt(1, idProduto);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getString("descricao");
            }
        }
        throw new SQLException("Produto não encontrado com o ID: " + idProduto);
    }

    public ArrayList<Venda> consultarVendasPorData(LocalDate data) {
        ArrayList<Venda> vendas = new ArrayList<>();
        String queryVendas = "SELECT * FROM venda WHERE data_venda = ?";
        String queryItens = "SELECT * FROM itens WHERE id_venda = ?";

        try (PreparedStatement psVendas = conexao.getConnection().prepareStatement(queryVendas)) {
            psVendas.setDate(1, java.sql.Date.valueOf(data));
            ResultSet rsVendas = psVendas.executeQuery();

            while (rsVendas.next()) {
                int idVenda = rsVendas.getInt("id_venda");
                int idVendedor = rsVendas.getInt("id_vendedor");
                int idCliente = rsVendas.getInt("id_cliente");
                int tipoPagamento = rsVendas.getInt("id_forma_pagamento");

                ArrayList<ItemVenda> itensVenda = new ArrayList<>();

                try (PreparedStatement psItens = conexao.getConnection().prepareStatement(queryItens)) {
                    psItens.setInt(1, idVenda);
                    ResultSet rsItens = psItens.executeQuery();

                    while (rsItens.next()) {
                        int quantidade = rsItens.getInt("quantidade");
                        float valorItem = rsItens.getFloat("preco_unitario");
                        float valorTotal = valorItem * quantidade;
                        ItemVenda itemVenda = new ItemVenda(quantidade, valorItem, valorTotal);
                        itensVenda.add(itemVenda);
                    }
                }

                Venda venda = new Venda(idVendedor, tipoPagamento, idCliente, itensVenda);
                vendas.add(venda);
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Trate o erro de forma adequada no seu sistema
        }

        return vendas;
    }

    public float buscarValorTotalPorId(int idVenda) {
        String query = "SELECT valor_total FROM vendas WHERE id = ?";
        float valorTotal = 0.0f;

        try (Connection conn = conexao.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, idVenda);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    valorTotal = rs.getFloat("valor_total");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Tratar adequadamente em um ambiente real
        }

        return valorTotal;
    }

}
