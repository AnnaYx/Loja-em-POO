package dao;

import model.Cliente;
import model.Vendedor;

import java.sql.*;
import java.util.Scanner;

public class VendedorDAO {

    private Conexao conexao;
    private String query;
    private PreparedStatement ps;

    public VendedorDAO() {
        conexao = Conexao.getConexao();
    }

    public void inserirVendedor(Vendedor v) {

        this.query = "INSERT INTO poo.vendedor(nome, sobrenome, dataNascimento, telefone, CPF, cidade, estado, pais, endereco, numero, email, senha, dataCadastro) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try{
            this.ps = conexao.getConnection().prepareStatement(this.query);
            this.ps.setString(1, v.getNome());
            this.ps.setString(2, v.getSobrenome());
            this.ps.setDate(3, Date.valueOf(v.getDataNascimento()));
            this.ps.setString(4, v.getTelefone());
            this.ps.setString(5, v.getCPF());
            this.ps.setString(6, v.getCidade());
            this.ps.setString(7, v.getEstado());
            this.ps.setString(8, v.getPais());
            this.ps.setString(9, v.getEndereco());
            this.ps.setInt(10, v.getNumero());
            this.ps.setString(11, v.getEmail());
            this.ps.setString(12, v.getSenha());
            this.ps.setTimestamp(13, Timestamp.valueOf(v.getDataCadastro()));
            this.ps.executeUpdate();
            this.ps.close();
        }
        catch(SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void listarVendedor() {
        this.query = "SELECT * FROM poo.vendedor";
        try {
            this.ps = conexao.getConnection().prepareStatement(this.query);
            ResultSet rs = ps.executeQuery();

            // Iterando sobre os resultados
            while (rs.next()) {
                int id = rs.getInt("id_vendedor");
                String nome = rs.getString("nome");
                String sobrenome = rs.getString("sobrenome");
                Date dataNascimento = rs.getDate("dataNascimento");
                String telefone = rs.getString("telefone");
                String cpf = rs.getString("CPF");
                String cidade = rs.getString("cidade");
                String estado = rs.getString("estado");
                String pais = rs.getString("pais");
                String endereco = rs.getString("endereco");
                int numero = rs.getInt("numero");
                Timestamp dataCadastro = rs.getTimestamp("dataCadastro");
                String email = rs.getString("email");
                String senha = rs.getString("senha");

                // Imprimindo os resultados
                System.out.println("ID: " + id);
                System.out.println("Nome: " + nome);
                System.out.println("Sobrenome: " + sobrenome);
                System.out.println("Data de Nascimento: " + dataNascimento);
                System.out.println("Telefone: " + telefone);
                System.out.println("CPF: " + cpf);
                System.out.println("Cidade: " + cidade);
                System.out.println("Estado: " + estado);
                System.out.println("País: " + pais);
                System.out.println("Endereço: " + endereco);
                System.out.println("Número: " + numero);
                System.out.println("Data de Cadastro: " + dataCadastro);
                System.out.println("Email: " + email);
                System.out.println("Senha: " + senha);
                System.out.println("-------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void editarVendedor(int id, Vendedor v) {
        String selectQuery = "SELECT * FROM poo.vendedor WHERE id_vendedor = ?";
        String updateQuery = "UPDATE poo.vendedor SET nome = ?, sobrenome = ?, dataNascimento = ?, telefone = ?, CPF = ?, cidade = ?, estado = ?, pais = ?, endereco = ?, numero = ?, email = ?, senha = ? WHERE id_vendedor = ?";

        try {
            // Primeiro, seleciona o vendedor pelo ID
            PreparedStatement psSelect = conexao.getConnection().prepareStatement(selectQuery);
            psSelect.setInt(1, id);
            ResultSet rs = psSelect.executeQuery();

            if (rs.next()) {
                // Se o vendedor com o ID especificado for encontrado, obtenha os dados atuais
                String nomeAtual = rs.getString("nome");
                String sobrenomeAtual = rs.getString("sobrenome");
                Date dataNascimentoAtual = rs.getDate("dataNascimento");
                String telefoneAtual = rs.getString("telefone");
                String cpfAtual = rs.getString("CPF");
                String cidadeAtual = rs.getString("cidade");
                String estadoAtual = rs.getString("estado");
                String paisAtual = rs.getString("pais");
                String enderecoAtual = rs.getString("endereco");
                int numeroAtual = rs.getInt("numero");
                String emailAtual = rs.getString("email");
                String senhaAtual = rs.getString("senha");

                // Verifica se os novos valores foram fornecidos e se são diferentes dos atuais
                String novoNome = (v.getNome() != null) ? v.getNome() : nomeAtual;
                String novoSobrenome = (v.getSobrenome() != null) ? v.getSobrenome() : sobrenomeAtual;
                Date novaDataNascimento = (v.getDataNascimento() != null) ? Date.valueOf(v.getDataNascimento()) : dataNascimentoAtual;
                String novoTelefone = (v.getTelefone() != null) ? v.getTelefone() : telefoneAtual;
                String novoCpf = (v.getCPF() != null) ? v.getCPF() : cpfAtual;
                String novaCidade = (v.getCidade() != null) ? v.getCidade() : cidadeAtual;
                String novoEstado = (v.getEstado() != null) ? v.getEstado() : estadoAtual;
                String novoPais = (v.getPais() != null) ? v.getPais() : paisAtual;
                String novoEndereco = (v.getEndereco() != null) ? v.getEndereco() : enderecoAtual;
                int novoNumero = (v.getNumero() != 0) ? v.getNumero() : numeroAtual;
                String novoEmail = (v.getEmail() != null) ? v.getEmail() : emailAtual;
                String novaSenha = (v.getSenha() != null) ? v.getSenha() : senhaAtual;

                // Atualiza o vendedor com os novos valores
                PreparedStatement psUpdate = conexao.getConnection().prepareStatement(updateQuery);
                psUpdate.setString(1, novoNome);
                psUpdate.setString(2, novoSobrenome);
                psUpdate.setDate(3, novaDataNascimento);
                psUpdate.setString(4, novoTelefone);
                psUpdate.setString(5, novoCpf);
                psUpdate.setString(6, novaCidade);
                psUpdate.setString(7, novoEstado);
                psUpdate.setString(8, novoPais);
                psUpdate.setString(9, novoEndereco);
                psUpdate.setInt(10, novoNumero);
                psUpdate.setString(11, novoEmail);
                psUpdate.setString(12, novaSenha);
                psUpdate.setInt(13, id);

                // Executa a atualização
                int linhasAfetadas = psUpdate.executeUpdate();
                if (linhasAfetadas > 0) {
                    System.out.println("Vendedor com ID " + id + " atualizado com sucesso!");
                } else {
                    System.out.println("Falha ao atualizar o vendedor com ID " + id);
                }
            } else {
                System.out.println("Vendedor com ID " + id + " não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void apagarVendedor(int id) {
        String deleteQuery = "DELETE FROM poo.vendedor WHERE id_vendedor = ?";

        try {
            Connection conn = conexao.getConnection();
            PreparedStatement ps = conn.prepareStatement(deleteQuery);
            ps.setInt(1, id);

            int linhasAfetadas = ps.executeUpdate();
            if (linhasAfetadas > 0) {
                System.out.println("Vendedor com ID " + id + " apagado com sucesso!");
            } else {
                System.out.println("Falha ao apagar o vendedor com ID " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean autenticarVendedor(String email, String senha) {
        String query = "SELECT * FROM poo.vendedor WHERE email = ? AND senha = ?";

        try {
            PreparedStatement ps = conexao.getConnection().prepareStatement(query);
            ps.setString(1, email);
            ps.setString(2, senha);

            ResultSet rs = ps.executeQuery();
            return rs.next(); // Retorna true se existir uma linha correspondente no resultado
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
