package model;

public class Adm extends Pessoa {

    //construtor
    public Adm(String nome, String email, String senha) {
        super(nome, email, senha); //invoca o construtor de pessoa que inicializa nome, email e senha
    }
}
