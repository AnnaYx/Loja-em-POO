package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

//construtor
public class Cliente extends Pessoa{

    //construtor
    public Cliente(String nome, String sobrenome, LocalDate dataNascimento, String telefone, String cpf, String cidade, String estado, String pais, String endereco, int numero, String email, String senha, LocalDateTime dataCadastro){
        super(nome, sobrenome, dataNascimento, telefone, cpf, cidade, estado, pais, endereco, numero, email, senha, dataCadastro);
    }
    public Cliente(){}

}
