package model;

import dao.VendaDAO;

import java.time.LocalDate;
import java.util.ArrayList;

public class ControleFechamentoDia {
    private VendaDAO vendaDAO;

    public ControleFechamentoDia() {
        this.vendaDAO = new VendaDAO();
    }


    public void fechamentoDoDia(LocalDate dataFechamento) {
        float totalDinheiro = 0;
        float totalDebito = 0;

        ArrayList<Venda> vendasDoDia = vendaDAO.consultarVendasPorData(dataFechamento);

        for (Venda venda : vendasDoDia) {
            if (venda.getTipoPagamento() == 3) {
                totalDinheiro += venda.getValorTotal();
            } else if (venda.getTipoPagamento() == 2) {
                totalDebito += venda.getValorTotal();

            }
        }

        System.out.println("Fechamento do dia " + dataFechamento);
        System.out.println("Total em dinheiro: R$" + totalDinheiro);
        System.out.println("Total em débito: R$" + totalDebito);
    }
    public static float calcularTotalVenda(Venda venda) {
        float total = 0;
        for (ItemVenda item : venda.getItens()) {
            total += item.getPrecoUnitario() * item.getQuantidade();
        }
        return total;
    }

}
