package model;

import java.time.LocalDateTime;
import java.util.Date;

public class Fornecedor extends Pessoa{
    private String CNPJ;
    private String razaoSocial;
    private String nomeFantasia;

    //construtor
    public Fornecedor(String nomeFantasia, String razaoSocial, String telefone, String CNPJ, String cidade, String estado, String pais, String endereco, int numero, String email, String senha, LocalDateTime dataCadastro) {
        super(telefone, cidade, estado, pais, endereco, numero, email, senha, dataCadastro);
        this.CNPJ = CNPJ;
        this.razaoSocial = razaoSocial;
        this.nomeFantasia = nomeFantasia;
    }

    public Fornecedor(){}

    //get e set do fornecedor
    public String getCNPJ() {
        return CNPJ;
    }

    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }
}
