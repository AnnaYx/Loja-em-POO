package model;

import java.util.Date;

public class ItemVenda {
    private int idProduto;
    private String produtoNome;
    private int quantidade;
    private float precoUnitario;
    private float valorItem;
    private Date dataVenda;
    private String clienteNome;
    private String vendedorNome;
    private String formaPagamento;
    private float valorTotalVenda;

    public ItemVenda(int idProduto, String produtoNome, int quantidade, float precoUnitario, float valorItem) {
        this.idProduto = idProduto;
        this.produtoNome = produtoNome;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
        this.valorItem = valorItem;
    }
    public ItemVenda(String produtoNome, int quantidade, float precoUnitario, float valorItem) {
        this.produtoNome = produtoNome;
        this.quantidade = quantidade;
        this.precoUnitario = precoUnitario;
        this.valorItem = valorItem;
    }

    public ItemVenda(int quantidade, float precoUnitario, float valorItem){}

    public int getIdProduto() {
        return idProduto;
    }

    public String getProdutoNome() {
        return produtoNome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public float getPrecoUnitario() {
        return precoUnitario;
    }

    public float getValorItem() {
        return valorItem;
    }
    public Date getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(Date dataVenda) {
        this.dataVenda = dataVenda;
    }

    public String getClienteNome() {
        return clienteNome;
    }

    public void setClienteNome(String clienteNome) {
        this.clienteNome = clienteNome;
    }

    public String getVendedorNome() {
        return vendedorNome;
    }

    public void setVendedorNome(String vendedorNome) {
        this.vendedorNome = vendedorNome;
    }

    public String getFormaPagamento() {
        return formaPagamento;
    }

    public void setFormaPagamento(String formaPagamento) {
        this.formaPagamento = formaPagamento;
    }

    public double getValorTotalVenda() {
        return valorTotalVenda;
    }

    public void setValorTotalVenda(float valorTotalVenda) {
        this.valorTotalVenda = valorTotalVenda;
    }
}
