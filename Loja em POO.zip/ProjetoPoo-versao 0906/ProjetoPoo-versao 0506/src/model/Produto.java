package model;

public class Produto {
    private int quantidade;
    private float preco;
    private String descricao;
    private int idFornecedor;


    //construtor
    public Produto(String descricao, int quantidade, float preco, int idFornecedor){
        this.quantidade = quantidade;
        this.preco = preco;
        this.descricao = descricao;
        this.idFornecedor = idFornecedor;
    }

    public Produto(){}

    // get e set

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getIdFornecedor() {
        return idFornecedor;
    }

    public void setIdFornecedor(int idFornecedor) {
        this.idFornecedor = idFornecedor;
    }
}
