package model;

import java.util.ArrayList;

public class Venda {
    private int idVendedor;
    private int tipoPagamento;
    private int cliente;
    private ArrayList<ItemVenda> itens;
    private float valorTotal;

    //construtor
    public Venda(int idVendedor, int tipoPagamento, int cliente, ArrayList<ItemVenda> itens) {
        this.idVendedor = idVendedor;
        this.tipoPagamento = tipoPagamento;
        this.cliente = cliente;
        this.itens = itens;
    }

    //get e set para vendas


    public float getValorTotal() {
        return valorTotal;
    }

    public void setValorTotal(float valorTotal) {
        this.valorTotal = valorTotal;
    }

    public int getIdVendedor() {
        return idVendedor;
    }

    public void setIdVendedor(int idVendedor) {
        this.idVendedor = idVendedor;
    }

    public int getTipoPagamento() {
        return tipoPagamento;
    }

    public void setTipoPagamento(int tipoPagamento) {
        this.tipoPagamento = tipoPagamento;
    }

    public int getCliente() {
        return cliente;
    }

    public void setCliente(int cliente) {
        this.cliente = cliente;
    }

    public ArrayList<ItemVenda> getItens() {
        return itens;
    }

    public void setItens(ArrayList<ItemVenda> itens) {
        this.itens = itens;
    }
}
