package model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

public class Vendedor extends Pessoa {

    //construtor
    public Vendedor(String nome, String sobrenome, LocalDate dataNascimento, String telefone, String CPF, String cidade, String estado, String pais, String endereco, int numero, String email, String senha,  LocalDateTime dataCadastro){
        super(nome, sobrenome, dataNascimento, telefone, CPF, cidade, estado, pais, endereco, numero, email, senha, dataCadastro);

    }
    public Vendedor(){}
}
